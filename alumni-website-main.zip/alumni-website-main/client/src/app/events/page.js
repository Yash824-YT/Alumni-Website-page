'use client';
import { useState, useEffect } from 'react';
import { eventsAPI } from '@/lib/api';
import { useAuth } from '@/context/AuthContext';

export default function EventsPage() {
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [category, setCategory] = useState('');
  const [showUpcoming, setShowUpcoming] = useState(true);
  const [message, setMessage] = useState('');
  const [registeringId, setRegisteringId] = useState(null);
  const { user } = useAuth();

  const categories = ['Reunion', 'Workshop', 'Seminar', 'Networking', 'Cultural', 'Sports', 'Other'];
  const categoryIcons = {
    Reunion: '🎉', Workshop: '🔧', Seminar: '📚', Networking: '🤝', Cultural: '🎭', Sports: '⚽', Other: '📌'
  };

  useEffect(() => {
    fetchEvents();
  }, [category, showUpcoming]);

  const fetchEvents = async () => {
    setLoading(true);
    try {
      const params = { limit: 50 };
      if (category) params.category = category;
      if (showUpcoming) params.upcoming = 'true';
      const res = await eventsAPI.getAll(params);
      setEvents(res.data.events);
    } catch (err) {
      console.error('Error fetching events:', err);
    }
    setLoading(false);
  };

  const handleRegister = async (eventId) => {
    if (!user) {
      setMessage('Please login to register for events');
      return;
    }
    setRegisteringId(eventId);
    try {
      const res = await eventsAPI.register(eventId);
      setMessage(res.data.message);
      fetchEvents();
    } catch (err) {
      setMessage(err.response?.data?.message || 'Failed to register');
    }
    setRegisteringId(null);
    setTimeout(() => setMessage(''), 3000);
  };

  return (
    <div className="min-h-screen bg-slate-50 fade-in">
      {/* Header */}
      <div className="gradient-bg py-16 px-4">
        <div className="max-w-7xl mx-auto text-center">
          <h1 className="text-4xl font-bold text-white mb-3">Events & Reunions</h1>
          <p className="text-indigo-200 text-lg max-w-2xl mx-auto">
            Stay connected by joining workshops, reunions, seminars, and networking events
          </p>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 -mt-8">
        {/* Filter Bar */}
        <div className="card !p-5 mb-8 !rounded-2xl">
          <div className="flex flex-col sm:flex-row items-center gap-4">
            <div className="flex flex-wrap gap-2 flex-1">
              <button
                onClick={() => setCategory('')}
                className={`px-4 py-2 rounded-xl text-sm font-medium transition-all ${
                  category === '' ? 'gradient-bg text-white shadow-md' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                All
              </button>
              {categories.map(cat => (
                <button
                  key={cat}
                  onClick={() => setCategory(cat)}
                  className={`px-4 py-2 rounded-xl text-sm font-medium transition-all ${
                    category === cat ? 'gradient-bg text-white shadow-md' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {categoryIcons[cat]} {cat}
                </button>
              ))}
            </div>
            <label className="flex items-center gap-2 text-sm text-slate-600 shrink-0 cursor-pointer">
              <input
                type="checkbox"
                checked={showUpcoming}
                onChange={(e) => setShowUpcoming(e.target.checked)}
                className="w-4 h-4 accent-indigo-600 rounded"
              />
              Upcoming only
            </label>
          </div>
        </div>

        {/* Message */}
        {message && (
          <div className="mb-6 p-4 bg-indigo-50 text-indigo-700 rounded-xl text-sm font-medium border border-indigo-100 slide-up">
            {message}
          </div>
        )}

        {/* Events Grid */}
        {loading ? (
          <div className="grid md:grid-cols-2 gap-6">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="card animate-pulse">
                <div className="h-5 bg-slate-200 rounded w-2/3 mb-3" />
                <div className="h-4 bg-slate-200 rounded w-1/3 mb-4" />
                <div className="h-3 bg-slate-200 rounded w-full mb-2" />
                <div className="h-3 bg-slate-200 rounded w-3/4" />
              </div>
            ))}
          </div>
        ) : events.length === 0 ? (
          <div className="text-center py-20">
            <div className="text-6xl mb-4">📅</div>
            <h3 className="text-xl font-bold text-slate-700 mb-2">No events found</h3>
            <p className="text-slate-500">Check back later for upcoming events</p>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 gap-6 mb-12">
            {events.map((event) => {
              const eventDate = new Date(event.date);
              const isPast = eventDate < new Date();
              return (
                <div key={event._id} className={`card group !rounded-2xl ${isPast ? 'opacity-60' : ''}`}>
                  <div className="flex items-start gap-4">
                    {/* Date Badge */}
                    <div className="shrink-0 w-16 h-16 rounded-2xl bg-indigo-50 flex flex-col items-center justify-center">
                      <span className="text-xs font-bold text-indigo-400 uppercase">
                        {eventDate.toLocaleDateString('en-US', { month: 'short' })}
                      </span>
                      <span className="text-2xl font-black text-indigo-600">
                        {eventDate.getDate()}
                      </span>
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className="text-lg font-bold text-slate-800 truncate">{event.title}</h3>
                      </div>
                      <div className="flex flex-wrap items-center gap-3 text-sm text-slate-500 mb-3">
                        <span>{categoryIcons[event.category] || '📌'} {event.category}</span>
                        <span>📍 {event.location}</span>
                        {event.time && <span>🕐 {event.time}</span>}
                      </div>
                      <p className="text-sm text-slate-600 line-clamp-2 mb-3">{event.description}</p>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3 text-xs text-slate-400">
                          <span>👥 {event.attendees?.length || 0} registered</span>
                          {event.maxAttendees > 0 && (
                            <span className="text-amber-500">/ {event.maxAttendees} max</span>
                          )}
                        </div>
                        {!isPast && (
                          <button
                            onClick={() => handleRegister(event._id)}
                            disabled={registeringId === event._id}
                            className="btn-primary !py-2 !px-5 text-sm"
                          >
                            {registeringId === event._id ? 'Registering...' : 'Register →'}
                          </button>
                        )}
                        {isPast && (
                          <span className="text-xs text-slate-400 font-medium bg-slate-100 px-3 py-1 rounded-full">Event ended</span>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
