'use client';
import { useState, useEffect } from 'react';
import { jobsAPI } from '@/lib/api';
import { useAuth } from '@/context/AuthContext';

export default function JobsPage() {
  const [jobs, setJobs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [typeFilter, setTypeFilter] = useState('');
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [applyingId, setApplyingId] = useState(null);
  const [message, setMessage] = useState('');
  const { user } = useAuth();

  useEffect(() => {
    fetchJobs();
  }, [page, typeFilter]);

  const fetchJobs = async () => {
    setLoading(true);
    try {
      const params = { page, limit: 10 };
      if (search) params.search = search;
      if (typeFilter) params.type = typeFilter;
      const res = await jobsAPI.getAll(params);
      setJobs(res.data.jobs);
      setTotalPages(res.data.totalPages);
    } catch (err) {
      console.error('Error fetching jobs:', err);
    }
    setLoading(false);
  };

  const handleApply = async (jobId) => {
    if (!user) {
      setMessage('Please login to apply for jobs');
      return;
    }
    setApplyingId(jobId);
    try {
      const res = await jobsAPI.apply(jobId);
      setMessage(res.data.message);
      fetchJobs();
    } catch (err) {
      setMessage(err.response?.data?.message || 'Failed to apply');
    }
    setApplyingId(null);
    setTimeout(() => setMessage(''), 3000);
  };

  const typeColors = {
    'Full-time': 'bg-emerald-50 text-emerald-700',
    'Part-time': 'bg-amber-50 text-amber-700',
    'Internship': 'bg-blue-50 text-blue-700',
    'Contract': 'bg-purple-50 text-purple-700',
    'Remote': 'bg-cyan-50 text-cyan-700'
  };

  return (
    <div className="min-h-screen bg-slate-50 fade-in">
      {/* Header */}
      <div className="gradient-bg py-16 px-4">
        <div className="max-w-7xl mx-auto text-center">
          <h1 className="text-4xl font-bold text-white mb-3">Job Board</h1>
          <p className="text-indigo-200 text-lg max-w-2xl mx-auto">
            Discover career opportunities shared by alumni and partner organizations
          </p>
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 -mt-8">
        {/* Search & Filters */}
        <div className="card !p-6 mb-8 !rounded-2xl">
          <form onSubmit={(e) => { e.preventDefault(); setPage(1); fetchJobs(); }} className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1 relative">
              <svg className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
              <input
                type="text"
                placeholder="Search jobs by title, company, location..."
                className="input-field !pl-12"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                id="jobs-search"
              />
            </div>
            <select
              className="input-field !w-auto min-w-[160px]"
              value={typeFilter}
              onChange={(e) => { setTypeFilter(e.target.value); setPage(1); }}
              id="jobs-type-filter"
            >
              <option value="">All Types</option>
              <option value="Full-time">Full-time</option>
              <option value="Part-time">Part-time</option>
              <option value="Internship">Internship</option>
              <option value="Contract">Contract</option>
              <option value="Remote">Remote</option>
            </select>
            <button type="submit" className="btn-primary shrink-0">Search</button>
          </form>
        </div>

        {/* Message Toast */}
        {message && (
          <div className="mb-6 p-4 bg-indigo-50 text-indigo-700 rounded-xl text-sm font-medium border border-indigo-100 slide-up">
            {message}
          </div>
        )}

        {/* Jobs List */}
        {loading ? (
          <div className="space-y-4">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="card animate-pulse">
                <div className="h-5 bg-slate-200 rounded w-1/3 mb-3" />
                <div className="h-4 bg-slate-200 rounded w-1/4 mb-4" />
                <div className="h-3 bg-slate-200 rounded w-full mb-2" />
                <div className="h-3 bg-slate-200 rounded w-2/3" />
              </div>
            ))}
          </div>
        ) : jobs.length === 0 ? (
          <div className="text-center py-20">
            <div className="text-6xl mb-4">💼</div>
            <h3 className="text-xl font-bold text-slate-700 mb-2">No jobs found</h3>
            <p className="text-slate-500">Check back later for new opportunities</p>
          </div>
        ) : (
          <div className="space-y-4 mb-12">
            {jobs.map((job) => (
              <div key={job._id} className="card group !rounded-2xl">
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
                  <div className="flex-1">
                    <div className="flex flex-wrap items-center gap-3 mb-2">
                      <h3 className="text-xl font-bold text-slate-800">{job.title}</h3>
                      <span className={`text-xs px-3 py-1 rounded-full font-semibold ${typeColors[job.type] || 'bg-slate-100 text-slate-600'}`}>
                        {job.type}
                      </span>
                    </div>
                    <div className="flex flex-wrap items-center gap-4 text-sm text-slate-500 mb-4">
                      <span className="flex items-center gap-1.5">🏢 {job.company}</span>
                      <span className="flex items-center gap-1.5">📍 {job.location}</span>
                      {job.salary && <span className="flex items-center gap-1.5">💰 {job.salary}</span>}
                      <span className="flex items-center gap-1.5">👥 {job.applicants?.length || 0} applicants</span>
                    </div>
                    <p className="text-sm text-slate-600 leading-relaxed mb-3">{job.description}</p>
                    {job.requirements && (
                      <div className="mt-3">
                        <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-1">Requirements</p>
                        <p className="text-sm text-slate-500">{job.requirements}</p>
                      </div>
                    )}
                    <p className="text-xs text-slate-400 mt-3">
                      Posted {new Date(job.createdAt).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}
                      {job.postedBy?.name && ` by ${job.postedBy.name}`}
                    </p>
                  </div>
                  <button
                    onClick={() => handleApply(job._id)}
                    disabled={applyingId === job._id}
                    className="btn-primary shrink-0 !py-2.5 !px-6 text-sm"
                    id={`apply-job-${job._id}`}
                  >
                    {applyingId === job._id ? 'Applying...' : 'Apply Now →'}
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex justify-center gap-2 mb-12">
            <button onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1} className="px-4 py-2 text-sm font-medium text-slate-600 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 disabled:opacity-50 transition-colors">← Prev</button>
            <span className="px-4 py-2 text-sm font-medium text-slate-500">Page {page} of {totalPages}</span>
            <button onClick={() => setPage(p => Math.min(totalPages, p + 1))} disabled={page === totalPages} className="px-4 py-2 text-sm font-medium text-slate-600 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 disabled:opacity-50 transition-colors">Next →</button>
          </div>
        )}
      </div>
    </div>
  );
}
