'use client';
import { useState, useEffect } from 'react';
import { notesAPI } from '@/lib/api';
import { useAuth } from '@/context/AuthContext';

export default function NotesPage() {
  const [notes, setNotes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('');
  const [departmentFilter, setDepartmentFilter] = useState('');
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [total, setTotal] = useState(0);
  const [message, setMessage] = useState('');
  const { user } = useAuth();

  // Admin upload form
  const [showUpload, setShowUpload] = useState(false);
  const [newNote, setNewNote] = useState({
    title: '', description: '', category: 'Notes', subject: '',
    department: 'General', year: '', fileUrl: '', content: ''
  });

  const categories = ['Notes', 'Previous Year Questions', 'Study Material', 'Syllabus', 'Other'];
  const departments = ['AIML', 'Computer Engineering ', 'Electrical Engineering', 'Mechanical Engineering', 'Civil Engineering', 'Electronics', 'Information Technology', 'Business Administration', 'Sciences'];

  const categoryIcons = {
    'Notes': '📝', 'Previous Year Questions': '📋', 'Study Material': '📚',
    'Syllabus': '📖', 'Other': '📌'
  };

  const categoryColors = {
    'Notes': 'bg-blue-50 text-blue-700',
    'Previous Year Questions': 'bg-purple-50 text-purple-700',
    'Study Material': 'bg-emerald-50 text-emerald-700',
    'Syllabus': 'bg-amber-50 text-amber-700',
    'Other': 'bg-slate-100 text-slate-600'
  };

  useEffect(() => { fetchNotes(); }, [page, categoryFilter, departmentFilter]);

  const fetchNotes = async () => {
    setLoading(true);
    try {
      const params = { page, limit: 12 };
      if (search) params.search = search;
      if (categoryFilter) params.category = categoryFilter;
      if (departmentFilter) params.department = departmentFilter;
      const res = await notesAPI.getAll(params);
      setNotes(res.data.notes);
      setTotalPages(res.data.totalPages);
      setTotal(res.data.total);
    } catch (err) {
      console.error('Error fetching notes:', err);
    }
    setLoading(false);
  };

  const handleUpload = async (e) => {
    e.preventDefault();
    try {
      await notesAPI.create(newNote);
      setMessage('Note uploaded successfully! ✅');
      setShowUpload(false);
      setNewNote({ title: '', description: '', category: 'Notes', subject: '', department: 'General', year: '', fileUrl: '', content: '' });
      fetchNotes();
    } catch (err) {
      setMessage(err.response?.data?.message || 'Failed to upload note ❌');
    }
    setTimeout(() => setMessage(''), 3000);
  };

  const handleDownload = async (note) => {
    try {
      await notesAPI.trackDownload(note._id);
      if (note.fileUrl) {
        window.open(note.fileUrl, '_blank');
      } else if (note.content) {
        const blob = new Blob([note.content], { type: 'text/plain' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `${note.title}.txt`;
        a.click();
        URL.revokeObjectURL(url);
      }
      fetchNotes();
    } catch (err) {
      console.error('Download error:', err);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 fade-in">
      {/* Header */}
      <div className="gradient-bg py-16 px-4">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="text-center sm:text-left">
            <h1 className="text-4xl font-bold text-white mb-2">📚 Notes & Resources</h1>
            <p className="text-indigo-200 text-lg">Access previous year questions, study materials, and alumni notes</p>
          </div>
          {user?.role === 'admin' && (
            <button onClick={() => setShowUpload(true)} className="bg-white text-indigo-600 font-semibold py-2.5 px-6 rounded-xl hover:bg-indigo-50 transition-all text-sm">
              + Upload Note
            </button>
          )}
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-8">
        {/* Message */}
        {message && (
          <div className="mb-6 p-4 bg-indigo-50 text-indigo-700 rounded-xl text-sm font-medium border border-indigo-100 slide-up">{message}</div>
        )}

        {/* Search & Filters */}
        <div className="card !p-6 mb-8 !rounded-2xl">
          <form onSubmit={(e) => { e.preventDefault(); setPage(1); fetchNotes(); }} className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <svg className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
              <input
                type="text" placeholder="Search notes, subjects..."
                className="input-field !pl-12"
                value={search} onChange={(e) => setSearch(e.target.value)}
              />
            </div>
            <select className="input-field !w-auto min-w-[200px]" value={categoryFilter}
              onChange={(e) => { setCategoryFilter(e.target.value); setPage(1); }}>
              <option value="">All Categories</option>
              {categories.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
            <select className="input-field !w-auto min-w-[180px]" value={departmentFilter}
              onChange={(e) => { setDepartmentFilter(e.target.value); setPage(1); }}>
              <option value="">All Departments</option>
              {departments.map(d => <option key={d} value={d}>{d}</option>)}
            </select>
            <button type="submit" className="btn-primary shrink-0">Search</button>
          </form>
        </div>

        {/* Category Quick Filters */}
        <div className="flex flex-wrap gap-2 mb-8">
          <button onClick={() => { setCategoryFilter(''); setPage(1); }}
            className={`px-4 py-2 rounded-xl text-sm font-medium transition-all ${!categoryFilter ? 'gradient-bg text-white shadow-md' : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'}`}>
            All
          </button>
          {categories.map(cat => (
            <button key={cat} onClick={() => { setCategoryFilter(cat); setPage(1); }}
              className={`px-4 py-2 rounded-xl text-sm font-medium transition-all ${categoryFilter === cat ? 'gradient-bg text-white shadow-md' : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'}`}>
              {categoryIcons[cat]} {cat}
            </button>
          ))}
        </div>

        {/* Results */}
        <p className="text-sm text-slate-500 mb-4">
          Showing <span className="font-semibold text-slate-700">{notes.length}</span> of <span className="font-semibold text-slate-700">{total}</span> resources
        </p>

        {/* Notes Grid */}
        {loading ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="card animate-pulse">
                <div className="h-5 bg-slate-200 rounded w-2/3 mb-3" />
                <div className="h-4 bg-slate-200 rounded w-1/3 mb-4" />
                <div className="h-3 bg-slate-200 rounded w-full mb-2" />
                <div className="h-3 bg-slate-200 rounded w-3/4" />
              </div>
            ))}
          </div>
        ) : notes.length === 0 ? (
          <div className="text-center py-20">
            <div className="text-6xl mb-4">📚</div>
            <h3 className="text-xl font-bold text-slate-700 mb-2">No notes found</h3>
            <p className="text-slate-500">Check back later for new study materials</p>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
            {notes.map((note) => (
              <div key={note._id} className="card group !rounded-2xl">
                <div className="flex items-start justify-between mb-3">
                  <span className={`text-xs px-3 py-1 rounded-full font-semibold ${categoryColors[note.category] || 'bg-slate-100 text-slate-600'}`}>
                    {categoryIcons[note.category]} {note.category}
                  </span>
                  <span className="text-xs text-slate-400">📥 {note.downloads}</span>
                </div>
                <h3 className="text-lg font-bold text-slate-800 mb-1 line-clamp-2">{note.title}</h3>
                <p className="text-sm text-indigo-600 font-medium mb-2">{note.subject}</p>
                {note.description && (
                  <p className="text-sm text-slate-500 line-clamp-2 mb-3">{note.description}</p>
                )}
                <div className="flex flex-wrap items-center gap-2 text-xs text-slate-400 mb-4">
                  {note.department && note.department !== 'General' && (
                    <span className="bg-slate-100 px-2 py-1 rounded-lg">🎓 {note.department}</span>
                  )}
                  {note.year && (
                    <span className="bg-slate-100 px-2 py-1 rounded-lg">📅 {note.year}</span>
                  )}
                  {note.uploadedBy?.name && (
                    <span className="bg-slate-100 px-2 py-1 rounded-lg">👤 {note.uploadedBy.name}</span>
                  )}
                </div>
                <button onClick={() => handleDownload(note)}
                  className="btn-primary w-full text-sm !py-2.5 group-hover:shadow-lg transition-shadow">
                  {note.fileUrl ? '🔗 Open Resource' : '📥 Download'}
                </button>
              </div>
            ))}
          </div>
        )}

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex justify-center gap-2 mb-12">
            <button onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1}
              className="px-4 py-2 text-sm font-medium text-slate-600 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 disabled:opacity-50 transition-colors">← Prev</button>
            <span className="px-4 py-2 text-sm font-medium text-slate-500">Page {page} of {totalPages}</span>
            <button onClick={() => setPage(p => Math.min(totalPages, p + 1))} disabled={page === totalPages}
              className="px-4 py-2 text-sm font-medium text-slate-600 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 disabled:opacity-50 transition-colors">Next →</button>
          </div>
        )}
      </div>

      {/* Upload Modal (Admin) */}
      {showUpload && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm fade-in">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto p-6 slide-up">
            <div className="flex items-center justify-between mb-5">
              <h2 className="text-xl font-bold text-slate-800">📤 Upload Note</h2>
              <button onClick={() => setShowUpload(false)} className="w-8 h-8 rounded-lg bg-slate-100 text-slate-500 flex items-center justify-center hover:bg-slate-200">✕</button>
            </div>
            <form onSubmit={handleUpload} className="space-y-4">
              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-1">Title *</label>
                <input className="input-field" value={newNote.title} onChange={e => setNewNote({...newNote, title: e.target.value})} required />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-semibold text-slate-700 mb-1">Subject *</label>
                  <input className="input-field" value={newNote.subject} onChange={e => setNewNote({...newNote, subject: e.target.value})} required placeholder="e.g. Data Structures" />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-slate-700 mb-1">Category</label>
                  <select className="input-field" value={newNote.category} onChange={e => setNewNote({...newNote, category: e.target.value})}>
                    {categories.map(c => <option key={c} value={c}>{c}</option>)}
                  </select>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-semibold text-slate-700 mb-1">Department</label>
                  <select className="input-field" value={newNote.department} onChange={e => setNewNote({...newNote, department: e.target.value})}>
                    {departments.map(d => <option key={d} value={d}>{d}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-semibold text-slate-700 mb-1">Year</label>
                  <input className="input-field" value={newNote.year} onChange={e => setNewNote({...newNote, year: e.target.value})} placeholder="e.g. 2024" />
                </div>
              </div>
              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-1">File URL (Google Drive / link)</label>
                <input className="input-field" value={newNote.fileUrl} onChange={e => setNewNote({...newNote, fileUrl: e.target.value})} placeholder="https://drive.google.com/..." />
              </div>
              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-1">Description</label>
                <textarea className="input-field !min-h-[60px]" value={newNote.description} onChange={e => setNewNote({...newNote, description: e.target.value})} />
              </div>
              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-1">Content (plain text, optional)</label>
                <textarea className="input-field !min-h-[80px]" value={newNote.content} onChange={e => setNewNote({...newNote, content: e.target.value})} placeholder="Paste note content here if no file URL..." />
              </div>
              <div className="flex gap-3 pt-2">
                <button type="submit" className="btn-primary flex-1">Upload Note</button>
                <button type="button" onClick={() => setShowUpload(false)} className="btn-secondary flex-1">Cancel</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
